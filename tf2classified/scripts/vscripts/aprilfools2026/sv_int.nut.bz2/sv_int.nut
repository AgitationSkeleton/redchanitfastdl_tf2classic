Entities.EnableEntityListening();

::DoIncludeScript( "/AprilFools2026/mod_ignite_on_eat", this );
::DoIncludeScript( "/AprilFools2026/mod_shoot_self", this );

Msg( "April Fools 2026 scripts initialized.\n" );