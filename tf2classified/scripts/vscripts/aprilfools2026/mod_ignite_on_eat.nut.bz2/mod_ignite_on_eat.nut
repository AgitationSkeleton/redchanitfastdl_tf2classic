function ApplyBiteEffects( hPlayer )
{
	local flIgniteOnEat = self.GetAttribute( "mod ignite on eat", 0 );
	if ( flIgniteOnEat > 0 )
	{
		hPlayer.IgnitePlayerEx( flIgniteOnEat );
	}
	
	return true;
}

Hooks.Add( this, "OnEntitySpawned", function( hEntity )
{
	local szClassname = hEntity.GetClassname();
	if ( szClassname != "tf_weapon_lunchbox" && szClassname != "tf_weapon_lunchbox_drink" )
	{
		return;
	}
	
	local hScope = hEntity.GetOrCreatePrivateScriptScope();
	Hooks.Add( hScope, "ApplyBiteEffects", ApplyBiteEffects, "mod_ignite_on_eat" );
}, "mod_ignite_on_eat" );