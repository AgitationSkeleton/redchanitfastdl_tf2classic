::ListenToGameEvent( "player_shoot", function( hEvent )
{
    local hPlayer = GetPlayerFromUserID( hEvent.userid );
    if( !hPlayer )
    {
        return;
    }
  
    local hActiveWeapon = hPlayer.GetActiveWeapon()
    if( !hActiveWeapon  || hActiveWeapon.GetAttribute( "mod shoot self", 0 ) == 0 )
    {
        return;
    }
  
    hPlayer.TakeDamage( hPlayer.GetMaxHealth() + 10, Constants.FDmgType.DMG_PREVENT_PHYSICS_FORCE, hPlayer );

    local hRagdoll = NetProps.GetPropEntity( hPlayer, "m_hRagdoll" );
    if ( hRagdoll )
    {
        hRagdoll.EmitSound( "Weapon_Scatter_Gun.Single" );
    }

    local angEyeAngles = hPlayer.EyeAngles()

    angEyeAngles.x = -angEyeAngles.x;
    angEyeAngles.y += 180;
    if ( angEyeAngles.y > 180 )
    {
        angEyeAngles.y -= 360;
    }

    hPlayer.SnapEyeAngles( angEyeAngles );
}, "mod_shoot_self" );