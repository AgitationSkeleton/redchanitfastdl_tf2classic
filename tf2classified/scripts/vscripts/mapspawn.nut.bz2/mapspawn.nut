if ( IsServer() )
{
	::DoIncludeScript( "/AprilFools2026/sv_int", this );
}